/* Total Orders */

SELECT COUNT(DISTINCT order_id) AS Total_Orders FROM pizza_sales